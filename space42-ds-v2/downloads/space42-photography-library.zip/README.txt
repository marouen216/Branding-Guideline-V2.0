SPACE42 PHOTOGRAPHY LIBRARY · 15 licensed stock photographs (JPG)

Supplied at 3,000 px on the long side, ready for presentations, web and documents.
For large-format print, request the full-resolution original from Space42 marketing and communications (quote the file number).
Approved: real operational environments, human + intelligence overlays, integration visuals.
Avoid: sci-fi imagery, decorative galaxy backgrounds, overdramatic space fantasy.
Licensed for Space42 use only. Do not share outside Space42.
