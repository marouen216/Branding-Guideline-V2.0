SPACE42 WORD TEMPLATES (A4)

Space42-Letterhead.dotx                   Letters on Space42 letterhead. Fill in the address line in the footer once and save your own copy.
Space42-Letterhead-Star.dotx              Letterhead for Star. Add the registered legal name and address in the footer.
Space42-Letterhead-Mira-Aerospace.dotx    Letterhead for Mira Aerospace. Add the registered legal name and address in the footer.
Space42-Letterhead-Thuraya.dotx           Letterhead for Thuraya. Add the registered legal name and address in the footer.
Space42-Memo.dotx                         Internal memos: to, from, date, subject, summary, detail, next steps.
Space42-Report.dotx                       Reports with cover, contents, numbered headings and a branded table.

Double-click a template to start a new document from it.
Paragraphs are Verdana, so documents look the same on every machine. Titles use Antarctica Expanded: install it from the Space42 fonts pack.
Use the built-in styles (Title, Heading 1–3, Normal, Label, Small) instead of formatting text by hand.
In the report, right-click the contents and choose Update Field after editing headings.
