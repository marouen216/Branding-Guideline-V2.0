SPACE42 SATELLITE FLEET · official cutouts on transparent ground (PNG)

Al Yah 2   GEO communications. Ka-band satcom over MENA; launched 2012, 47.5°E.
Al Yah 3   GEO communications (HTS). All-Ka-band high-throughput satellite covering Brazil and Africa; launched 2018.
Al Yah 4   GEO communications (next-gen). Flexible software-defined GEO satellite (Airbus), ordered 2023.
Al Yah 5   GEO communications (next-gen). Flexible software-defined GEO satellite (Airbus), ordered 2023.
Thuraya 2  GEO mobile satellite services. L-band MSS satellite with large deployable mesh reflector, in service since 2003.
Thuraya 4  GEO mobile satellite services (next-gen). Thuraya 4-NGS, L-band MSS (Airbus Eurostar Neo), launched January 2025.
Foresight  LEO SAR Earth observation. Constellation of 5 satellites (Foresight-1 to Foresight-5).

Use: always let the satellite float on a background (Blue42, space imagery or white). Never place it in a box and never re-crop it.
Large renders are supplied at 3,508 px wide: full A4 width at 300 dpi.
