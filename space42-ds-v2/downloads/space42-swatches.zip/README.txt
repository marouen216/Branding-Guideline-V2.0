SPACE42 SWATCH LIBRARY

Space42-colours.ase          Adobe swatches. Illustrator, InDesign, Photoshop: Swatches panel menu > Open Swatch Library > Other Library.
Space42-colour-palette.pdf   The palette at a glance: HEX, RGB, CMYK and Pantone.
Space42-colour-palette.png   Same sheet as an image.
Space42-palette.csv          Every value in a spreadsheet, including the blue ramp.

Core: Blue42 #121A6B · White #FFFFFF · Solar #FF6B35 · Sand #E8DCC4 · Pulse #2AC0E6 · Cosmos #0F0533
Accents (Solar, Sand, Pulse) stay within 20% of any composition and are never used as text on white.
