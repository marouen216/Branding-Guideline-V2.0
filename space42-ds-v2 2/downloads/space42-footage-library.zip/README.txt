SPACE42 FOOTAGE LIBRARY · 5 licensed stock clips (MP4, H.264, 1920x1080, no audio)

Ready for presentations, social and web. For broadcast or large-screen use, request the original master from Space42 marketing and communications (quote the file number).
Motion: slow and steady, real before rendered, graded to the brand. Text and graphics go on clean areas of the frame, never over faces.
Licensed for Space42 use only. Do not share outside Space42.
